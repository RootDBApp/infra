Use this setup only for a quick test on your local workstation.


# **TL.DR** - Up and running in 20 seconds

```bash
docker compose --env-file env up
```

RootDB will be available at [localhost:8091](http://localhost:8091)
