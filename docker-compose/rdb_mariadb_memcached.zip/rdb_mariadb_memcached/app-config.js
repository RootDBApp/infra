window.appConfig = {
    'REACT_APP_API_URL': 'http://localhost:8090',
    'REACT_APP_VITE_REVERB_APP_KEY': 'jetuePoh5uyeeth8oom1Aeg8Lae7guchie2ieba3ahyai',
    'REACT_APP_VITE_REVERB_HOST': 'localhost',
    'REACT_APP_VITE_REVERB_PORT': '8081',
    'REACT_APP_VITE_REVERB_SCHEME': 'http',
};
