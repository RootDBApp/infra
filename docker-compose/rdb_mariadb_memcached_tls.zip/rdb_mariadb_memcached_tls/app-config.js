window.appConfig = {
    'REACT_APP_API_URL': 'https://api_hostname_tld:443',
    'REACT_APP_ECHO_CLIENT_KEY': '941437ead078ff691c47862511a81fe1d494ba87',
    'REACT_APP_ECHO_CLIENT_CLUSTER': 'rootdb-api-localhost-cluster',
    'REACT_APP_ECHO_CLIENT_AUTHENDPOINT': 'https://api_hostname_tld:443/broadcasting/auth',
    'REACT_APP_ECHO_CLIENT_WS_HOST': 'api_hostname_tld',
    'REACT_APP_ECHO_CLIENT_WS_PORT': '6001',
    'REACT_APP_ECHO_CLIENT_WSS_HOST': 'api_hostname_tld',
    'REACT_APP_ECHO_CLIENT_WSS_PORT': '6001',
};
